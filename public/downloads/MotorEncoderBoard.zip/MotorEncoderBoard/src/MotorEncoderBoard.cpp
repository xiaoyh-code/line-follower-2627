#include "MotorEncoderBoard.h"

// ============================================================
// Motor Driver
// ============================================================

#define I2C_ADDR 0x34

// Registers

#define MOTOR_TYPE_ADDR              0x14
#define MOTOR_ENCODER_POLARITY_ADDR  0x15
#define MOTOR_FIXED_SPEED_ADDR       0x33
#define MOTOR_ENCODER_TOTAL_ADDR     0x3C


// ============================================================
// Constructor
// ============================================================

MotorEncoderBoard::MotorEncoderBoard()
{
    i2cBus = 0;

    // JGB37:
    //
    // 44 encoder pulses
    // 90:1 gearbox
    //
    // 44 × 90 = 3960

    pulsesPerRevolution = 3960;
}


// ============================================================
// Begin
// ============================================================

void MotorEncoderBoard::begin(
    int sda,
    int scl,
    int bus,
    uint8_t motorType
)
{
    i2cBus = bus;


    // I2C Bus 0

    if (i2cBus == 0)
    {
        Wire.begin(
            sda,
            scl,
            100000
        );
    }


    // I2C Bus 1

    else
    {
        Wire1.begin(
            sda,
            scl,
            100000
        );
    }


    delay(200);


    writeRegister(MOTOR_TYPE_ADDR, motorType);


    delay(5);


    // Encoder polarity

    writeRegister(
        MOTOR_ENCODER_POLARITY_ADDR,
        0
    );


    delay(100);


    // Stop motors

    setSpeed(
        0,
        0,
        0,
        0
    );
}


// ============================================================
// Write one register
// ============================================================

void MotorEncoderBoard::writeRegister(
    uint8_t reg,
    uint8_t value
)
{
    if (i2cBus == 0)
    {
        Wire.beginTransmission(I2C_ADDR);

        Wire.write(reg);

        Wire.write(value);

        Wire.endTransmission();
    }

    else
    {
        Wire1.beginTransmission(I2C_ADDR);

        Wire1.write(reg);

        Wire1.write(value);

        Wire1.endTransmission();
    }
}


// ============================================================
// Set Motor Speed
//
// Closed-loop speed control
//
// motor.setSpeed(M1, M2, M3, M4);
//
// Example forward:
//
// motor.setSpeed(0, 23, 0, -23);
// ============================================================

void MotorEncoderBoard::setSpeed(
    int8_t motor1,
    int8_t motor2,
    int8_t motor3,
    int8_t motor4
)
{
    if (i2cBus == 0)
    {
        Wire.beginTransmission(I2C_ADDR);

        Wire.write(MOTOR_FIXED_SPEED_ADDR);

        Wire.write(motor1);
        Wire.write(motor2);
        Wire.write(motor3);
        Wire.write(motor4);

        Wire.endTransmission();
    }

    else
    {
        Wire1.beginTransmission(I2C_ADDR);

        Wire1.write(MOTOR_FIXED_SPEED_ADDR);

        Wire1.write(motor1);
        Wire1.write(motor2);
        Wire1.write(motor3);
        Wire1.write(motor4);

        Wire1.endTransmission();
    }
}


// ============================================================
// Read the four signed, little-endian encoder totals together.
// ============================================================

bool MotorEncoderBoard::readEncoders(int32_t (&counts)[4])
{
    TwoWire& bus = i2cBus == 0 ? Wire : Wire1;

    bus.beginTransmission(I2C_ADDR);
    bus.write(MOTOR_ENCODER_TOTAL_ADDR);
    if (bus.endTransmission(false) != 0)
        return false;

    if (bus.requestFrom(I2C_ADDR, 16) != 16)
        return false;

    for (int32_t& count : counts)
    {
        uint32_t bits = 0;
        for (unsigned shift = 0; shift < 32; shift += 8)
            bits |= static_cast<uint32_t>(bus.read()) << shift;
        count = static_cast<int32_t>(bits);
    }
    return true;
}


long MotorEncoderBoard::readEncoder(int motorNumber)
{
    int32_t counts[4];
    if (motorNumber < 1 || motorNumber > 4 || !readEncoders(counts))
        return 0;

    return counts[motorNumber - 1];
}


// ============================================================
// Read Distance
//
// wheelDiameter is in mm
//
// Return value is also mm
//
// Formula:
//
// distance =
// encoder pulses
// ---------------- × π × diameter
// pulses/revolution
// ============================================================

float MotorEncoderBoard::readDistance(
    int motorNumber,
    float wheelDiameter
)
{
    long pulses =
        readEncoder(motorNumber);


    float circumference =
        PI * wheelDiameter;


    float revolutions =
        pulses /
        pulsesPerRevolution;


    float distance =
        revolutions *
        circumference;


    return distance;
}


// ============================================================
// Reset Encoder
// ============================================================

void MotorEncoderBoard::resetEncoder()
{
    if (i2cBus == 0)
    {
        Wire.beginTransmission(I2C_ADDR);

        Wire.write(MOTOR_ENCODER_TOTAL_ADDR);


        for (int i = 0; i < 16; i++)
        {
            Wire.write(0);
        }


        Wire.endTransmission();
    }

    else
    {
        Wire1.beginTransmission(I2C_ADDR);

        Wire1.write(MOTOR_ENCODER_TOTAL_ADDR);


        for (int i = 0; i < 16; i++)
        {
            Wire1.write(0);
        }


        Wire1.endTransmission();
    }
}


// ============================================================
// Change Pulses Per Revolution
// ============================================================

void MotorEncoderBoard::setPulsesPerRevolution(
    float pulses
)
{
    pulsesPerRevolution = pulses;
}