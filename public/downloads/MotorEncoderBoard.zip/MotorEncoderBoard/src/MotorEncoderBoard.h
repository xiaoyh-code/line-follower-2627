#ifndef MOTOR_ENCODER_BOARD_H
#define MOTOR_ENCODER_BOARD_H

#include <Arduino.h>
#include <Wire.h>

class MotorEncoderBoard
{
public:

    MotorEncoderBoard();

    // Start the motor board
    //
    // Example:
    // motor.begin(21, 22, 0);
    //
    // SDA = 21
    // SCL = 22
    // I2C bus = 0

    static constexpr uint8_t MOTOR_TYPE_TT = 1;
    static constexpr uint8_t MOTOR_TYPE_JGB37 = 3;

    void begin(
        int sda,
        int scl,
        int bus = 0,
        uint8_t motorType = MOTOR_TYPE_JGB37
    );


    // Control four motor speeds
    //
    // Example:
    // motor.setSpeed(0, 23, 0, -23);

    void setSpeed(
        int8_t motor1,
        int8_t motor2,
        int8_t motor3,
        int8_t motor4
    );


    // Read encoder pulse count
    //
    // Example:
    // long pulse = motor.readEncoder(2);

    long readEncoder(
        int motorNumber
    );


    // Read all four counters from one I2C transaction. False on a bus error.
    bool readEncoders(int32_t (&counts)[4]);


    // Read wheel travel distance in mm
    //
    // Example:
    // float distance = motor.readDistance(2, 65);

    float readDistance(
        int motorNumber,
        float wheelDiameter
    );

    // Reset all encoder counters

    void resetEncoder();

    // Change pulses per wheel revolution

    void setPulsesPerRevolution(
        float pulses
    );


private:

    int i2cBus;

    float pulsesPerRevolution;


    void writeRegister(
        uint8_t reg,
        uint8_t value
    );

};

#endif