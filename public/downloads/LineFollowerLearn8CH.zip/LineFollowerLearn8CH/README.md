# LineFollowerLearn8CH

Eight-channel IR line sensor states, analog readings and thresholds for ESP32.

## Installation

Install **esp32 by Espressif Systems** in Arduino IDE Boards Manager and select
**ESP32 Dev Module** and the USB port. Choose **Sketch → Include Library → Add
.ZIP Library…** and select this library's ZIP. Find the sketches under **File →
Examples** and open Serial Monitor at **115200 baud**. Wire comes with the ESP32
board package; no other library is needed for these examples.

If you installed the earlier combined **F5 DAT Line Follower** library, remove
that installed library before using these split libraries, to avoid duplicate
header selection. Back up old sketches and remove their duplicate driver .h/.cpp
files when switching to installed libraries. Your original includes and API calls
stay the same. The optional F5LineFollower wrapper from the combined package is
not included here; use MotorEncoderBoard and the sensor functions directly.

These packages target classic ESP32, whose core provides both Wire and Wire1.
Other ESP32 variants with only one I2C controller are not claimed compatible.
Use bus 0 or 1; the classroom examples use bus 0 at 100 kHz, SDA21 and SCL22.
Connect common ground and use ESP32-compatible 3.3 V I2C signals. Power the boards
according to their hardware specifications; do not power motors from GPIO.

## Sensor API

```cpp
#include <LineFollowerLearn8CH.h>
linefollower_8ch linefollower{};
```

- `LineFollowerLearn8CH_IIC_init(21, 22, 0)` selects shared bus 0. Address: 0x5D.
- `detect_state_all_channel_IIC(&linefollower)` refreshes `state_all_ch[0..7]`
  in S1–S8 order. Read before printing. In I2C mode, detected line = 1.
- `get_AnalogVoltage_all_channel_IIC(&linefollower)` refreshes
  `AnalogVoltage_all_ch[0..7]`; examples print raw returned values.
- `get_ThresholdValue_all_channel_IIC(&linefollower)` refreshes
  `ThresholdVoltage_all_ch[0..7]`.

Perform hardware self-learning/calibration before line following. Verify channel
order by moving the line under the board; physical left/right depends on mounting.
The header's extern `linefollower` declaration requires one definition in your
sketch if you use that variable name, as shown above. No definition is added in
the library, so existing sketches do not acquire duplicate globals.

The original global `i2C_Bus` supports one sensor bus configuration per sketch.
Legacy read functions do not report I2C failures; disconnected sensors can return
misleading states. The original GPIO functions remain available, with inverted
line polarity compared with I2C, but their fixed pins 6–9 can conflict with flash
on classic ESP32. Use the supplied I2C examples for this course.

## Using both libraries

Install both ZIPs, include both headers, and initialize both devices with
`(21, 22, 0)`. They share SDA/SCL and ground; different addresses select each
board. Each library is independent and its examples compile without the other.
The separately supplied `Both_Boards_Test.ino` shows them together.

## Provenance

All included original driver files are byte-for-byte copies of the uploads.
Existing copyright and attribution are retained; no new license or ownership
claim is applied. The metadata URL is empty because no project URL was supplied.
