/**
 * @file LineFollowerLearn8CH.cpp
 * @brief 幻尔科技Hiwonder--八路灰度巡线传感器通信及数据处理库(抽象层应用)
 *
 * @author ZhiYuan (Gilbert@hiwonder.com)
 * @date 26-01-22
 * @version 1.0
 * @note 此文件只涉及模块工作逻辑调度，具体底层硬件操作详见”LineFollowerLearn8CH_Porting”，移植时无需修改
 *
 * @copyright Copyright (c) 2023
 */

#include "LineFollowerLearn8CH.h"
#include "string.h"

//========================================================================IIC通信API==========================================================================

/**
 * @brief IIC通信方式获取各通道状态值并解析
 *
 * @param linefollower_8ch *obj：八路灰度巡线传感器对象
 * @note StateReg_OriginData为传感器发来的原始数据，可供调试观测、
 * @note 识别到线段，对应通道状态值为高电平（和GPIO方式获取数据相反）
 */
void detect_state_all_channel_IIC(linefollower_8ch *obj){
	uint8_t len=0;
	
	i2c_read_data(LineFollowerLearn8CH_I2C_ADDR, SensorStateReg, &(obj->StateReg_OriginData), sizeof(obj->StateReg_OriginData));
	
	for(len = 0; len < SENSOR_SUM; len++)
	{
		obj->state_all_ch[len]= ((obj->StateReg_OriginData >> len) & 0x01); //解析数据，提取各通道状态值
	}
	
}

/**
 * @brief IIC通信方式获取各通道模拟量并解析
 *
 * @param linefollower_8ch *obj：八路灰度巡线传感器对象
 * @note SensorAnalogReg_OriginData为传感器发来的原始数据，可供调试观测
 */
void get_AnalogVoltage_all_channel_IIC(linefollower_8ch *obj){
	uint8_t len=0;
	uint8_t count=0;
	
	i2c_read_data(LineFollowerLearn8CH_I2C_ADDR, SensorAnalogReg_ch1, obj->SensorAnalogReg_OriginData, sizeof(obj->SensorAnalogReg_OriginData));
	
	for(len = 0,count = 0; len < SENSOR_SUM; len++)
	{
		obj->AnalogVoltage_all_ch[len]= (obj->SensorAnalogReg_OriginData[count]) | (obj->SensorAnalogReg_OriginData[count+1]<<8);  //解析数据，把各通道模拟值低8位和高8位数据合并为16位数据
		count += 2;
	}
}

/**
 * @brief IIC通信方式获取各通道阈值量并解析
 *
 * @param linefollower_8ch *obj：八路灰度巡线传感器对象
 * @note SensorThresholdReg_OriginData为传感器发来的原始数据，可供调试观测
 */
void get_ThresholdValue_all_channel_IIC(linefollower_8ch *obj){
	uint8_t len = 0;
	uint8_t count=0;

	i2c_read_data(LineFollowerLearn8CH_I2C_ADDR, SensorThresholdReg_ch1, obj->SensorThresholdReg_OriginData, sizeof(obj->SensorThresholdReg_OriginData));
	
	for(len = 0,count = 0; len < SENSOR_SUM; len++)
	{
		obj->ThresholdVoltage_all_ch[len]= (obj->SensorThresholdReg_OriginData[count]) | (obj->SensorThresholdReg_OriginData[count+1]<<8);  //解析数据，把各通道阈值低8位和高8位数据合并为16位数据
		count += 2;
	}
}

//========================================================================GPIO通信API==========================================================================

/**
 * @brief GPUI通信方式获取各通道状态值并解析
 *
 * @param linefollower_8ch *obj：八路灰度巡线传感器对象
 * @note  识别到线段，对应通道状态值为低电平（和IIC方式获取数据相反）
 */
void detect_state_all_channel_GPIO(linefollower_8ch *obj){
	uint8_t len=0;
	
	for(len = 0; len < SENSOR_SUM; len++)
	{
		obj->state_all_ch[len]= detect_state_one_channel_GPIO(len); //解析数据，提取各通道状态值
    delayms(5);
	}
	
}
