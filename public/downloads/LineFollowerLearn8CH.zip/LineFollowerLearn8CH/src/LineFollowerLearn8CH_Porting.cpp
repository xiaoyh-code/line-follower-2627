/**
 * @file LineFollowerLearn8CH_Porting.cpp
 * @brief 幻尔科技Hiwonder--八路灰度巡线传感器通信及数据处理库(硬件层应用)
 *
 * @author ZhiYuan (Gilbert@hiwonder.com)
 * @date 26-01-22
 * @version 1.0
 * @note 此文件涉及模块操作中具体硬件平台API接口调用，移植时修改此处
 *
 * @copyright Copyright (c) 2023
 */

#include "LineFollowerLearn8CH_Porting.h"

/**
 * @brief 完成八路灰度巡线传感器IIC通信前必要的硬件接口初始化。
 */

int i2C_Bus = 1;

void LineFollowerLearn8CH_IIC_init(int sda, int scl, int bus) {

  i2C_Bus = bus;

  if (i2C_Bus == 0) {
    Wire.begin(sda, scl, 100000);
  } else {
    Wire1.begin(sda, scl, 100000);
  }
}

/**
 * @brief 读取指定地址设备，指定寄存器的指定字节数据，存放到指定空间。
 * @param Addr IIC设备地址
 * @param Reg  IIC设备寄存器
 * @param buf_pointer 数据存储空间地址  
 * @param len  读取数据长度  
 */
void i2c_read_data(unsigned char Addr, unsigned char Reg, unsigned char *buf_pointer, int len) {

  if (i2C_Bus == 0) {
    Wire.beginTransmission(Addr);
    Wire.write(Reg);
    Wire.endTransmission(false);

    Wire.requestFrom((int)Addr, (int)len);

    for (int i = 0; i < len; i++) {
      buf_pointer[i] = Wire.read();
    }
  }

  else {
    Wire1.beginTransmission(Addr);
    Wire1.write(Reg);
    Wire1.endTransmission(false);

    Wire1.requestFrom((int)Addr, (int)len);

    for (int i = 0; i < len; i++) {
      buf_pointer[i] = Wire1.read();
    }
  }
}

/**
 * @brief 设置GPIO引脚电平。
 */
void Write_pin_level(int pin, bool value) {
  digitalWrite(pin, value);
}

/**
 * @brief 读取GPIO引脚电平。
 */
bool Read_pin_level(int pin) {
  return digitalRead(pin);
}

/**
 * @brief 读取八路灰度传感器单个通道状态值
 * @param channel_num  通道号（0-7）。
 */
bool detect_state_one_channel_GPIO(int channel_num) {
  Write_pin_level(AD0_PIN, ((channel_num >> 0) & 0x01));
  Write_pin_level(AD1_PIN, ((channel_num >> 1) & 0x01));
  Write_pin_level(AD2_PIN, ((channel_num >> 2) & 0x01));
  delayms(5);

  return Read_pin_level(OUT_PIN);  //解析数据，提取对应通道状态值
}

/**
 * @brief 完成八路灰度巡线传感器GPIO通信前必要的硬件接口初始化。
 */
void LineFollowerLearn8CH_GPIO_init() {
  pinMode(AD0_PIN, OUTPUT);
  pinMode(AD1_PIN, OUTPUT);
  pinMode(AD2_PIN, OUTPUT);
  pinMode(OUT_PIN, INPUT);
}

/**
 * @brief 八路灰度巡线传感器延时操作接口。
 */
void delayms(int ms) {
  delay(ms);
}