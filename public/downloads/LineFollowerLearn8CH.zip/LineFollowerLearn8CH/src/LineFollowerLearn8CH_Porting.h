#include "Arduino.h"
#include "Wire.h"

// 定义GPIO通信引脚
#define AD0_PIN 6
#define AD1_PIN 7
#define AD2_PIN 8
#define OUT_PIN 9

extern int i2C_Bus;


void LineFollowerLearn8CH_IIC_init(int sda, int scl, int Bus);
void i2c_read_data(unsigned char Addr, unsigned char Reg, unsigned char *buf_pointer, int len);

void LineFollowerLearn8CH_GPIO_init();
void Write_pin_level(int pin, bool value);
bool Read_pin_level(int pin);
bool detect_state_one_channel_GPIO(int channel_num);

void delayms(int ms);