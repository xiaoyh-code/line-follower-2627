#ifndef __LINEFOLLOWERLERAN8CH_H_
#define __LINEFOLLOWERLERAN8CH_H_

#include "LineFollowerLearn8CH_Porting.h"

#define SENSOR_SUM 8  //传感器通道数
/*======================================================IIC通信部分宏定义===========================================*/
#define LineFollowerLearn8CH_I2C_ADDR 0x5D //传感器I2C地址

#define SensorStateReg      (5u)  //传感器全通道状态数据寄存器地址

#define SensorAnalogReg_ch1     (6u)   //传感器通道1模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch2     (8u) 	 //传感器通道2模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch3     (10u)  //传感器通道3模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch4     (12u)  //传感器通道4模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch5     (14u)  //传感器通道5模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch6     (16u)  //传感器通道6模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch7     (18u)  //传感器通道7模拟值寄存器,读2Byte数据，低位在前，高位在后
#define SensorAnalogReg_ch8     (20u)  //传感器通道8模拟值寄存器,读2Byte数据，低位在前，高位在后

#define SensorThresholdReg_ch1  (22u)  //传感器通道1阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch2  (24u)  //传感器通道2阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch3  (26u)  //传感器通道3阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch4  (28u)  //传感器通道4阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch5  (30u)  //传感器通道5阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch6  (32u)  //传感器通道6阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch7  (34u)  //传感器通道7阈值寄存器,读2Byte数据，低位在前，高位在后
#define SensorThresholdReg_ch8  (36u)  //传感器通道8阈值寄存器,读2Byte数据，低位在前，高位在后

/*======================================================GPIO通信部分宏定义===========================================*/



/* 八路灰度巡线传感器结构体 */
typedef struct{
	unsigned char StateReg_OriginData;                    //从传感器收到的通道状态原始数据（低八位在前，高八位在后）
	unsigned char state_all_ch[8];                        //通道状态（每一个元素代表一个通道）
	
	unsigned char SensorAnalogReg_OriginData[16];         //从传感器收到的通道模拟量原始数据（低八位在前，高八位在后）
	unsigned short AnalogVoltage_all_ch[8];               //通道模拟量（每一个元素代表一个通道）
	
	unsigned char SensorThresholdReg_OriginData[16];      //从传感器收到的通道阈值原始数据（低八位在前，高八位在后） 
	unsigned short ThresholdVoltage_all_ch[8];            //通道阈值（每一个元素代表一个通道）
	
}linefollower_8ch;

void detect_state_all_channel_IIC(linefollower_8ch *obj);
void get_AnalogVoltage_all_channel_IIC(linefollower_8ch *obj);
void get_ThresholdValue_all_channel_IIC(linefollower_8ch *obj);

void detect_state_all_channel_GPIO(linefollower_8ch *obj);

extern linefollower_8ch linefollower;

#endif